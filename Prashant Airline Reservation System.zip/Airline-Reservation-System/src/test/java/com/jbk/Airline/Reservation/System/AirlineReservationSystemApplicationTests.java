package com.jbk.Airline.Reservation.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineReservationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
