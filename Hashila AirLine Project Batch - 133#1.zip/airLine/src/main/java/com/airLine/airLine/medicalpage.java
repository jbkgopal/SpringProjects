package com.airLine.airLine;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class medicalpage {
	
	@Id
	String name;
	String text;
	int age;
	String currentPos;
	String radiobuttons;
	String mostLike;
	String prefer;
	String comment;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getCurrentPos() {
		return currentPos;
	}
	public void setCurrentPos(String currentPos) {
		this.currentPos = currentPos;
	}
	public String getRadiobuttons() {
		return radiobuttons;
	}
	public void setRadiobuttons(String radiobuttons) {
		this.radiobuttons = radiobuttons;
	}
	public String getMostLike() {
		return mostLike;
	}
	public void setMostLike(String mostLike) {
		this.mostLike = mostLike;
	}
	public String getPrefer() {
		return prefer;
	}
	public void setPrefer(String prefer) {
		this.prefer = prefer;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "medicalpage [name=" + name + ", text=" + text + ", age=" + age + ", currentPos=" + currentPos
				+ ", radiobuttons=" + radiobuttons + ", mostLike=" + mostLike + ", prefer=" + prefer + ", comment="
				+ comment + "]";
	}

	
}
