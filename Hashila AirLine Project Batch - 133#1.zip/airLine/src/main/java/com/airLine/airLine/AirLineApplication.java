package com.airLine.airLine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirLineApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirLineApplication.class, args);
		System.err.println("airLine");
	}

}
