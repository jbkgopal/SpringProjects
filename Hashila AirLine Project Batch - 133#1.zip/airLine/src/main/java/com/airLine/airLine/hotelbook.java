package com.airLine.airLine;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class hotelbook {
	@Id
	int passportno;
	String name;
	String email;
	String subject;
	String msg;
	public int getPassportno() {
		return passportno;
	}
	public void setPassportno(int passportno) {
		this.passportno = passportno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	@Override
	public String toString() {
		return "hotelbook [passportno=" + passportno + ", name=" + name + ", email=" + email + ", subject=" + subject
				+ ", msg=" + msg + "]";
	}
	

}
