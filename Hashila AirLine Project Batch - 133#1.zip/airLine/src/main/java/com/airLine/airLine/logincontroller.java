package com.airLine.airLine;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class logincontroller {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("/")
    public String tocall() {
		return "login";
	}
	
	@RequestMapping("login")
	public Object Tosend(@ModelAttribute loginpage p ,Model model) {
		Session ss=sf.openSession();
		loginpage dblogin = ss.get(loginpage.class, p.getUsername());
		String page = "login";
		String msg = null;

		if (dblogin != null) {
			if (p.getPassword().equals(dblogin.getPassword())) {

				page = "home";

			} else {
				msg = "invalid Password";
			}
		} else {
			msg = "invalid Username";
		}
		model.addAttribute("msg", msg);
		return page;
	}
	
	
	
	

   @RequestMapping("/contactPage")
   public String Tocontact() {
	   return "contact";
   }
	
   
   @RequestMapping("contact")
	public contact Todata(@ModelAttribute contact c1) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(c1);
		tx.commit();
		System.out.println(c1);
		return c1;
	}
	
	
	@RequestMapping("/servicePage")
	public String toserv() {
		return "service";
	}
	
	@RequestMapping("/logoutPage")
	public String logoutpage() {
		return "login";
	}
	
	
	@RequestMapping("/hotelbookingpage")
	public String Tobookcar() {
		return "hotelbooking";
	}
	
	@RequestMapping("/hotelbooking")
	public hotelbook toshow(@ModelAttribute hotelbook h1) {
		
		
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(h1);
		tx.commit();
		System.out.println(h1);
		return h1;
	}
	
	@RequestMapping("/hotelpay")
	public String Topayhotel() {
		return "paynow";
	}
	@RequestMapping("paynow")
	public hotelpay topay(@ModelAttribute hotelpay h2 ) {
		
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		ss.save(h2);
		tx.commit();
		System.out.println(h2);
		return h2;
		
	}
	
	
	@RequestMapping("aboutPage")
		public String Todisplay() {
		return "about";
	}
	@RequestMapping("/homePage")
	public String Tohome() {
	return "home";
}
	
	@RequestMapping("/OurTeam")
	public String teamcall() {
		return "ourteam";
	}
	
	@RequestMapping("/medicalservice")
	public String tomedical() {
		return "medical";
	}
	
	@RequestMapping("medical")
	public medicalpage topay(@ModelAttribute medicalpage m2 ) {
		
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		ss.save(m2);
		tx.commit();
		System.out.println(m2);
		return m2;
		
	}
	@RequestMapping("/homepage")
	public String tohomeq() {
		return "home";
	}
	
	
}

	
