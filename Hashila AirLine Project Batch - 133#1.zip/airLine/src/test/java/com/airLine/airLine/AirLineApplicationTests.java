package com.airLine.airLine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirLineApplicationTests {

	@Test
	void contextLoads() {
	}

}
