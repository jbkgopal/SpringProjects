package com.JBK.SpringBoot.Crud.Operation;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.persistence.criteria.CriteriaQuery;

@Controller
public class StudentController {

	@Autowired
	SessionFactory sf;

	@RequestMapping("/")
	public String student() {
		return "student";
	}

	@RequestMapping("/student")
	public String addStudent(@ModelAttribute Student student) {

		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		ss.save(student);

		tx.commit();

		return null;
	}

	@RequestMapping("/viewtable")
	public ModelAndView viewtable() {

		Session ss = sf.openSession();

		Query query = ss.createQuery("from Student");

		List<Student> al = query.list();
		al.forEach(System.out::println);

		ModelAndView view = new ModelAndView();
		view.addObject("al", al);
		System.out.println(al);
		view.setViewName("viewStudentTable");

		return view;
	}

	@RequestMapping("/updateTable")
	String updateTable() {

		Session ss = sf.openSession();

		
		return "updateTable";
	}

	@RequestMapping("/deleteTable")
	Student deleteTable(@ModelAttribute Student student) {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		ss.delete(student);

		tx.commit();

		return student;
	}
}
