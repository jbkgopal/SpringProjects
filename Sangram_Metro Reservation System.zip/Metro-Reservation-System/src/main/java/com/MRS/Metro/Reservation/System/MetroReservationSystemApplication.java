package com.MRS.Metro.Reservation.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetroReservationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetroReservationSystemApplication.class, args);
		System.err.println("Springboot is running...");
	}

}
