package com.MRS.Metro.Reservation.System;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MRS_Controller {
	@Autowired
	SessionFactory sf;

@RequestMapping("/")
	public String login() {
	return "login";

	}

@RequestMapping("/login")
public String userlogin(@ModelAttribute Login login, Model model) {
Session ss=sf.openSession();

Login dalogin=ss.get(Login.class,login.getUsername());
String page="login";
String msg="msg";

if(dalogin!=null) {
	if(login.getPassword().equals(dalogin.getPassword())) {
		page="home";
	}
	else {
		msg="invalid password";
	}}
		else {
		msg="invalid username";
	}
model.addAttribute("msg", msg);
return page;
}

@RequestMapping("/aboutpage")
public String about() {
	return "about";
}

@RequestMapping("/contactpage")
public String contact() {
	return "contact";
}

@RequestMapping("/servicepage")
public String servicePage() {
	return "service";
}

@RequestMapping("/contact")
public String contactda(@ModelAttribute Contact contact, Model model) {
Session ss=sf.openSession();
Transaction tx=ss.beginTransaction();

ss.save(contact);
tx.commit();
return null;

}

@RequestMapping("/homepage")
public String backtohomePage() {
	return "home";
}

@RequestMapping("/logoutpage")
public String logoutPage() {
	return "login";
}

}






























