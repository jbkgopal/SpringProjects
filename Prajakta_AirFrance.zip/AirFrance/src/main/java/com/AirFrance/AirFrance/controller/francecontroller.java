package com.AirFrance.AirFrance.controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.AirFrance.AirFrance.model.Carbookdetail;
import com.AirFrance.AirFrance.model.Contact;
import com.AirFrance.AirFrance.model.Login;
import com.AirFrance.AirFrance.model.hotelbooking;
import com.AirFrance.AirFrance.model.payhere;

@Controller
public class francecontroller {
	
	@Autowired
	SessionFactory sf;
	
	@RequestMapping("/")
	public String tocall() {
		return "login";
		
	}
	
	@RequestMapping("login")
	public String Toset(@ModelAttribute Login l1, Model model) {
	Session ss=sf.openSession();
	
	Login dblogin=ss.get(Login.class, l1.getUsername());
	l1.getUsername().equals(l1.getUsername());
	String page="login";
	String msg = null;
	
	if(dblogin !=null) {
		if(l1.getPassword().equals(l1.getPassword())) {
			page="home";
		}else {
			msg="invalid password";
		}
	}else {
		msg="invalid Username";
	}
	model.addAttribute("msg",msg);
	return page;
	}
	
	
	
	@RequestMapping("/contactPage")
	public String Tojet() {
		return "contact";
	}
	
	@RequestMapping("contact")
	public Contact Toqwertyui(@ModelAttribute Contact c1) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(c1);
		tx.commit();
		System.out.println(c1);
		return c1;
	}
	
	@RequestMapping("/servicePage")
	public String Toservice() {
		return "Service";
	}
	
	
	@RequestMapping("/aboutPage")
	public String toabout() {
		return "about";
	}
	
	@RequestMapping("/logoutPage")
	public String Tologout() {
		return "login";
	}
	
	
	
	
	
	
	
	
	
	@RequestMapping("/carbookpage")
	public String Tocar() {
		return "carbooking";
	}
	
	@RequestMapping("carbooking")
	public Carbookdetail book(@ModelAttribute Carbookdetail b1) {
	Session ss=sf.openSession();
	Transaction tx=ss.beginTransaction();
	
	ss.save(b1);
	tx.commit();
	System.out.println(b1);
	return b1;
	}
	
	
	
	@RequestMapping("/Payherepage")
	public String topay() {
		return "payhere";
	}
	
	
	
	
	@RequestMapping("payhere")
	public payhere topaycar(@ModelAttribute payhere car) {
		Session ss=sf.openSession();
		Transaction tx=ss.beginTransaction();
		
		ss.save(car);
		tx.commit();
		System.out.println(car);
		return car;
	}
	

	
	@RequestMapping("/Hotelbooking")
	public String Tohotel() {
		return "hotelbooking";
	}
	
	@RequestMapping("hotelbooking")
	public hotelbooking book(@ModelAttribute hotelbooking h1){
	Session ss=sf.openSession();
	Transaction tx=ss.beginTransaction();
	
	ss.save(h1);
	tx.commit();
	System.out.println(h1);
	return h1;
	}
	
	@RequestMapping("homepage")
	public String Tohome() {
		return "home";
	}
	@RequestMapping("ourteampage")
	public String Toteam() {
		return"ourteam";
	}
	@RequestMapping("/hotelPayhere")
	public String Tohotelpay() {
		return "hotelpay";

	}
	
	@RequestMapping("/videopage")
	public String Tovideo() {
	  return "video" ;
	}
	
}
