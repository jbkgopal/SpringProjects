package com.AirFrance.AirFrance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirFranceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirFranceApplication.class, args);
		System.err.println("France");
	}

}
