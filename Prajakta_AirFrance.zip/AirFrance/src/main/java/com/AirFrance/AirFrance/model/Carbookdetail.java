package com.AirFrance.AirFrance.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Carbookdetail {
	@Id
	String passportnumber;
	String fullname;
	String phonenumber;
	String pickupdate;
	String pickuptime;
	String pickuplocation;
	String droplocation;
	String specialrequest;
	public Carbookdetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Carbookdetail(String passportnumber, String fullname, String phonenumber, String pickupdate,
			String pickuptime, String pickuplocation, String droplocation, String specialrequest) {
		super();
		this.passportnumber = passportnumber;
		this.fullname = fullname;
		this.phonenumber = phonenumber;
		this.pickupdate = pickupdate;
		this.pickuptime = pickuptime;
		this.pickuplocation = pickuplocation;
		this.droplocation = droplocation;
		this.specialrequest = specialrequest;
	}
	public String getPassportnumber() {
		return passportnumber;
	}
	public void setPassportnumber(String passportnumber) {
		this.passportnumber = passportnumber;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getPickupdate() {
		return pickupdate;
	}
	public void setPickupdate(String pickupdate) {
		this.pickupdate = pickupdate;
	}
	public String getPickuptime() {
		return pickuptime;
	}
	public void setPickuptime(String pickuptime) {
		this.pickuptime = pickuptime;
	}
	public String getPickuplocation() {
		return pickuplocation;
	}
	public void setPickuplocation(String pickuplocation) {
		this.pickuplocation = pickuplocation;
	}
	public String getDroplocation() {
		return droplocation;
	}
	public void setDroplocation(String droplocation) {
		this.droplocation = droplocation;
	}
	public String getSpecialrequest() {
		return specialrequest;
	}
	public void setSpecialrequest(String specialrequest) {
		this.specialrequest = specialrequest;
	}
	@Override
	public String toString() {
		return "Carbookdetail [passportnumber=" + passportnumber + ", fullname=" + fullname + ", phonenumber="
				+ phonenumber + ", pickupdate=" + pickupdate + ", pickuptime=" + pickuptime + ", pickuplocation="
				+ pickuplocation + ", droplocation=" + droplocation + ", specialrequest=" + specialrequest + "]";
	}
	
	
	
	
}
