package com.java.New.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HMSProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HMSProjectApplication.class, args);
		System.err.println("My website Running........");
	}

}
