package com.jbk.CMS.Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
