package com.HMS.Hospital.Management.System;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Login {

	@Id
	String username;
	String password;
	String national;
	String emailid;
	String mobileno;

	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Login(String username, String password, String national, String emailid, String mobileno) {
		super();
		this.username = username;
		this.password = password;
		this.national = national;
		this.emailid = emailid;
		this.mobileno = mobileno;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNational() {
		return national;
	}

	public void setNational(String national) {
		this.national = national;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	@Override
	public String toString() {
		return "Login [username=" + username + ", password=" + password + ", national=" + national + ", emailid="
				+ emailid + ", mobileno=" + mobileno + "]";
	}

}
